module Main where

import           Chapter9.FilesAndStreams
import           Chapter9.IOBasics              ( complementUser )

-- It's a convention in Haskell to not add a type annotation to the `main` function
main = complementUser
